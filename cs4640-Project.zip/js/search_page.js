function get_searchrent(){
    $( "#result" ).load( "./searchrent.html" );
}

function get_searchNumRes(){
    $( "#result" ).load( "./searchNumRes.html" );
}

function get_searchnearby(){
    $( "#result" ).load( "./searchnearby.php" );
}

function get_searchAme(){
    $( "#result" ).load( "./searchAme.html" );
}

function get_searchRoomType(){
    $( "#result" ).load( "./searchRoomType.html" );
}