<?php


echo "hi";
    /*
    */
?>